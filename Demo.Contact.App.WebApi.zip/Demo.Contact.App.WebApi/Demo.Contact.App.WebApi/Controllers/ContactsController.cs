﻿using Demo.Contact.App.BL.Contract;
using Demo.Contact.App.Entity.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace Demo.Contact.App.WebApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ContactsController : ControllerBase
    {
        public DemoContactsContext _context { get; }
        public IContactsBL _contactsBL { get; }

        public ContactsController(IContactsBL contactsBL, DemoContactsContext context)
        {
            _contactsBL = contactsBL;
            _context = context;
        }

        [Route("ActiveContacts")]
        [HttpGet]
      
        public IList<Contacts> GetActiveContacts()
        {
            try
            {
                return _contactsBL.GetActiveContacts();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("ContactsById")]
        public Contacts GetContactByID(int ContactId)
        {
            try
            {
                return _contactsBL.GetContactDetailsById(ContactId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
