﻿using Demo.Contact.App.BL.Contract;
using Demo.Contact.App.DAL.Contract;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Demo.Contact.App.Entity.Models;

namespace Demo.Contact.App.BL.Implementation
{
    public class ContactsBL : IContactsBL
    {
        public DemoContactsContext _context { get; }
        public IContactDAL _contactsDAL { get; }
        public ContactsBL(IContactDAL contactsDAL, DemoContactsContext context) 
        {
            _context = context;
            _contactsDAL = contactsDAL;
        }
        public IList<Contacts> GetActiveContacts()
        {
            return _contactsDAL.GetActiveContacts();
        }

        public Contacts GetContactDetailsById(int ContactId)
        {
            return _contactsDAL.GetContactDetailsById(ContactId);
        }
    }
}
