﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Contact.App.BL.Contract
{
    public static class BLCollectionExtentions
    {
        public static IServiceCollection RegisterBllServices(this IServiceCollection services, IConfiguration configuration)
        {
            //services.RegisterDBFromDAL(configuration);
            //services.AddScoped<IProductService, ProductService>();

            //return services;
            return null;
        }
    }
}
