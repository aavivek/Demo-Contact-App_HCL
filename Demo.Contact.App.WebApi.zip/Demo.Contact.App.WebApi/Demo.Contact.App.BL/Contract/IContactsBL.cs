﻿using System;
using System.Collections.Generic;
using System.Text;
using Demo.Contact.App.Entity.Models;

namespace Demo.Contact.App.BL.Contract
{
    public interface IContactsBL
    {
        public IList<Contacts> GetActiveContacts();
        public Contacts GetContactDetailsById(int ContactId);
    }
}
