﻿using Demo.Contact.App.Entity.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.Contact.App.DAL.Contract
{
    public interface IContactDAL
    {
        public IList<Contacts> GetActiveContacts();
        public Contacts GetContactDetailsById(int ContactId);
    }
}
