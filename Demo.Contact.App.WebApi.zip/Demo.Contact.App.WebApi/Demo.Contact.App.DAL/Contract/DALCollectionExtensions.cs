﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using Demo.Contact.App.DAL.Contract;
using Microsoft.EntityFrameworkCore;
//using Demo.Contact.App.Entity.Models;
using Demo.Contact.App.DAL.Implementation;

namespace Demo.Contact.App.DAL.Contract
{
    public static class DALCollectionExtensions
    {
        public static IServiceCollection RegisterDBFromDAL(this IServiceCollection services, IConfiguration configuration)
        {
            //services.AddScoped(typeof(IContactDAL<>), typeof(BaseRepository<>));
            //services.AddScoped<IContactDAL, ContactDAL>();
            //services.AddScoped(typeof(DbContext), typeof(DemoContactsContext));
            //services.AddEntityFrameworkSqlServer()  
            //    .AddDbContext<DemoContactsContext>(options =>
            //    {
            //        options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
            //    });

            //return services;
            return null;
        }
    }
}
