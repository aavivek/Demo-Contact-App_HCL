﻿using Demo.Contact.App.DAL.Contract;
using System;
using System.Collections.Generic;
using System.Text;
using Demo.Contact.App.Entity.Models;
using Microsoft.Extensions.Configuration;
using System.Linq;

namespace Demo.Contact.App.DAL.Implementation
{
    public class ContactDAL : IContactDAL
    {
        public DemoContactsContext _context { get; }
        public ContactDAL(DemoContactsContext context)
        {
            _context = context;
        }
        public IList<Contacts> GetActiveContacts()
        {
            IList<Contacts> objActiveContacts = _context.Contacts.AsQueryable()
                                                .Where(a => a.IsDeleted==false).ToList();            
            return objActiveContacts;
            
        }

        public Contacts GetContactDetailsById(int ContactId)
        {
            Contacts objContactDetails = _context.Contacts.AsQueryable()
                                                .Where(a => a.Id == ContactId).Single();
            return objContactDetails;

        }
    }
}
