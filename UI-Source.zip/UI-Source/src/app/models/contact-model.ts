export class ContactList{
    Id: number;
    Name:string;
    EmailAddress:string;
    PhoneNumber:string;
    Address:string;
    CreatedBy:string;
    ModifiedBy:string;
}