import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ConfigReaderService {
  private config: object = null;

  constructor(private http: HttpClient) { }

  public getJSON(): Promise<any> {
    return this.http.get<any>(environment.basePath+"/assets/config/config.json").pipe(tap(
      res => {
        this.config = res;
      }
    )).toPromise();
  }  

  public getSetting() {
    return this.config;
  }
}
