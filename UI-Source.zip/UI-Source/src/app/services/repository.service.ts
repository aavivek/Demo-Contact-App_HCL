import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpParams } from '@angular/common/http';
import { ConfigReaderService } from './config-reader.service';

@Injectable({
  providedIn: 'root'
})
export class RepositoryService {
  private configData: any;
  private apiUrl: any;
  private tokeninfo: any;
 
  private loginHeaders = new HttpHeaders({
    'content-type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-XSS-Protection': '1; mode=block'
  });

  constructor(private readonly httpClient: HttpClient, private readonly configReader: ConfigReaderService) { 
      this.configData = this.configReader.getSetting();
  }

  public Post(url: string, parameter: any = null) {
    this.apiUrl = this.configData.ServiceURL + url;
    return this.httpClient.post<any>(this.apiUrl, parameter,
      {
        headers: this.loginHeaders,
        withCredentials: true
      });
  }

  public Get(url: string, parameter: any = null) {
    this.apiUrl = this.configData.ServiceURL + url;
    return this.httpClient.get<any>(this.apiUrl,
      { 
        headers: this.loginHeaders, 
        params: parameter, 
        withCredentials: true 
      });
  }
}
