import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RepositoryService } from './repository.service';
import { ContactConstants } from '../constants/contact-constants';
import { ContactList } from '../models/contact-model';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private readonly reposervice:RepositoryService) { }

  public GetAllContactLists(): Observable<ContactList[]>  {
    return this.reposervice.Get(ContactConstants.GetContactDetails);
  }

  public GetContactById(contactId: number): Observable<ContactList>  {
    return this.reposervice.Get(ContactConstants.GetContactById,contactId);
  }
}
