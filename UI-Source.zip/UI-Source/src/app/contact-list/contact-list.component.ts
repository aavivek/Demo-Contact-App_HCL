import { Component, OnInit } from '@angular/core';
import { ContactList } from '../models/contact-model';
import { ContactService } from '../services/contact.service';
import { ContactConstants } from '../constants/contact-constants';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {

  constructor(private readonly contactservice: ContactService) { }

  contactListDetails = [];
  cols = [];
  EmptyTableMessage='';
 
  ngOnInit(): void {    
    this.EmptyTableMessage= this.contactListDetails!=null && this.contactListDetails.length==0
                          ? ContactConstants.Info_NoContacts : "";
    this.cols = [
      { field: 'name', header: 'Name' },
      { field: 'email', header: 'Email Address' },
      { field: 'phone', header: 'Phone Number' },
      { field: 'address', header: 'Address' },
    ];
    this.loadContactLists();
  }

  loadContactLists(){
    this.contactservice.GetAllContactLists().subscribe(
      result => {
        this.contactListDetails = result as ContactList[];
      },
      error => {
        this.loadDummyData();
      }
    );
  }

  loadDummyData(){
    this.contactListDetails=[
      { id:'1', name:'Vivek', email:'Vivek@gmail.com', phone:'123456789', address:'Chennai' },
      { id:'2', name:'Farooq', email:'Farooq@gmail.com', phone:'987654321', address:'Coimbatore'},
      { id:'3', name:'Utham Jain', email:'UthamJain@gmail.com', phone:'1325436789', address:'Hosur'},
      { id:'4', name:'Frank', email:'frank@gmail.com', phone:'745345463', address:'Madurai'},
      { id:'5', name:'Thenmozhi', email:'thenmozhi@gmail.com', phone:'745345463', address:'Erode'},
      { id:'6', name:'Ramesh', email:'ramesh@gmail.com', phone:'745345463', address:'Tenkasi'},
    ]
  }
}
