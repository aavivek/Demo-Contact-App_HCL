export class ContactConstants {
    public static GetContactDetails = 'GetContactDetailsList';
    public static GetContactById = 'GetContactById';
    public static Info_NoContacts = "No Contacts available to view";
}
