import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactService } from '../services/contact.service';

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.css']
})
export class ContactDetailsComponent implements OnInit {

  constructor(private readonly contactservice: ContactService,
              private readonly route: ActivatedRoute,
              private readonly router: Router) {  
    this.contactDetailsForm = new FormGroup({
      Name: this.Name,
      Email: this.Email,
      PhoneNo: this.PhoneNo,
      Address: this.Address,   
    });
  }

  public contactDetailsForm: FormGroup;
  public Name: FormControl = new FormControl('', [Validators.required]);
  public Email: FormControl = new FormControl('', [Validators.required]);
  public PhoneNo: FormControl = new FormControl('', [Validators.required]);
  public Address: FormControl = new FormControl('', [Validators.required]);
  contactId:number;

  ngOnInit(): void {
    this.route.queryParams
      .subscribe(params => {
        this.contactId = params[0];
      });
    this.loadContactDetails();
  }

  loadContactDetails(){
    this.contactservice.GetContactById(this.contactId).subscribe(
      result => {
        this.Name.setValue(result.Name);
        this.Email.setValue(result.EmailAddress);
        this.PhoneNo.setValue(result.PhoneNumber);
        this.Address.setValue(result.Address);
      },
      error => {
        this.loadDummyData();
      }
    );
  }

  loadDummyData(){
    this.Name.setValue("Dummy Name");
    this.Email.setValue("Dummy@gmail.com");
    this.PhoneNo.setValue("0000000000");
    this.Address.setValue("Dummay Address");
  }

  backClick(){
    this.router.navigateByUrl('');
  }
}
